// Usage:  npm run indexnow     (run after every deploy)
// Tells Bing, Yandex and other IndexNow search engines about every page URL at once, so new pages are found in hours, not weeks.
// (Google does not use IndexNow: for Google, submit /sitemap.xml once in Search Console; it then re-reads it by itself.)
import { readFileSync, readdirSync } from "node:fs";
const site = (process.env.VITE_SITE_URL || "https://www.saadcarremtal.com").replace(/\/+$/, "");
const keyFile = readdirSync("public").find((n) => /^[a-f0-9]{32}\.txt$/.test(n)); if (!keyFile) { console.error("No IndexNow key file in public/"); process.exit(1); }
const key = keyFile.replace(".txt", "");
const xml = (f) => { try { return readFileSync(`dist/${f}`, "utf8"); } catch { return ""; } };
const files = [...xml("sitemap.xml").matchAll(/<loc>[^<]*\/(sitemap-[a-z]+\.xml)<\/loc>/g)].map((m) => m[1]).filter((f) => f !== "sitemap-images.xml");
const urls = [...new Set(files.flatMap((f) => [...xml(f).matchAll(/<loc>([^<]*)<\/loc>/g)].map((m) => m[1])))];
if (!urls.length) { console.error("Run npm run build first (dist/ has no sitemap)."); process.exit(1); }
const res = await fetch("https://api.indexnow.org/indexnow", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ host: new URL(site).hostname, key, keyLocation: `${site}/${keyFile}`, urlList: urls }) });
console.log(`IndexNow: sent ${urls.length} URLs, answer ${res.status} (200 or 202 = accepted)`);
