// Usage:  npm run keywords:new -- "wedding car rental rawalpindi"
// Appends a DRAFT keyword page to src/seo/data/keywords/extra.js. A draft makes no page, so it can never break the build.
// Open extra.js, fill in the text (copy the style of city.js), change status to "live", then run npm run build.
import { readFileSync, writeFileSync } from "node:fs";
const phrase = process.argv.slice(2).join(" ").trim();
if (!phrase) { console.error('Give the search phrase, e.g.  npm run keywords:new -- "wedding car rental rawalpindi"'); process.exit(1); }
const slug = phrase.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const title = phrase.replace(/\b\w/g, (c) => c.toUpperCase());
const file = "src/seo/data/keywords/extra.js"; let s = readFileSync(file, "utf8");
if (s.includes(`slug: "${slug}"`)) { console.error(`Already exists: ${slug}`); process.exit(1); }
const entry = `  { slug: "${slug}", status: "draft", group: "city", title: "${title}", h1: "${title} With Professional Driver",
    description: "WRITE 70-160 characters here: what the visitor gets, where, and how to book.",
    eyebrow: "${title}", lead: "WRITE two sentences that answer why someone searches for '${phrase}'.",
    answer: ["WRITE the question people ask?", "WRITE a direct 2-sentence answer. Call or WhatsApp us with your date, pickup and destination and we reply with a quote."],
    sections: [{ h: "WRITE heading 1", c: ["WRITE a paragraph."] }, { h: "WRITE heading 2", c: ["WRITE a paragraph."] }, { h: "WRITE heading 3", c: ["WRITE a paragraph."] }],
    faqs: [{ q: "WRITE question 1?", a: "WRITE answer." }, { q: "WRITE question 2?", a: "WRITE answer." }, { q: "WRITE question 3?", a: "WRITE answer." }],
    terms: ["${phrase}"], vehicles: ["prado", "toyota-grande"], places: ["islamabad"], services: ["premium-car-rental"], related: ["rent-a-car-islamabad"],
    og: { a: "${title.toUpperCase().slice(0, 24)}", b: "With professional driver", vehicle: "prado" }, service: "Car rental with driver" },
`;
s = s.replace(/\n\];\s*$/, "\n" + entry + "];\n"); writeFileSync(file, s);
console.log(`Draft added: ${slug}\nEdit ${file}, fill every WRITE, set status: "live", then npm run build.`);
