// Usage:  npm run seo:suggest -- path/to/Queries.csv
// Finds REAL search phrases people already use to reach your site and tells you which ones have no page of their own yet.
// Get the file free: Google Search Console > Performance > Search results > Export > Download CSV, then use "Queries.csv".
import { readFileSync, existsSync } from "node:fs";
import { build } from "esbuild";
const f = process.argv[2]; if (!f || !existsSync(f)) { console.error("Give the Search Console Queries.csv path."); process.exit(1); }
const r = await build({ stdin: { contents: `import { KW_PAGES } from "./src/seo/data/keywords"; import { PLACES } from "./src/seo/data/places"; export default { KW_PAGES, PLACES };`, resolveDir: process.cwd(), loader: "js" }, bundle: true, write: false, format: "esm", platform: "node", define: { "import.meta.env": "{}" }, logLevel: "error" });
const { default: d } = await import("data:text/javascript;base64," + Buffer.from(r.outputFiles[0].text).toString("base64"));
const have = d.KW_PAGES.flatMap((k) => [k.title, k.h1, ...(k.terms || [])]).concat(d.PLACES.filter((p) => p.status === "live").map((p) => p.name)).map((x) => x.toLowerCase());
const words = (q) => q.toLowerCase().match(/[a-z0-9؀-ۿ]+/g) || [];
const covered = (q) => have.some((h) => { const w = words(q); return w.length && w.every((x) => h.includes(x)); });
const rows = readFileSync(f, "utf8").split(/\r?\n/).slice(1).filter(Boolean).map((l) => { const m = l.match(/^"?([^",]+)"?,(\d+),(\d+)/); return m && { q: m[1], clicks: +m[2], imp: +m[3] }; }).filter(Boolean);
const gaps = rows.filter((x) => !covered(x.q)).sort((a, b) => b.imp - a.imp).slice(0, 40);
console.log(`${rows.length} queries read, ${gaps.length} without a page. Biggest gaps first:\n`);
gaps.forEach((g) => console.log(`${String(g.imp).padStart(6)} impressions  ${String(g.clicks).padStart(4)} clicks   ${g.q}   ->   npm run keywords:new -- "${g.q}"`));
