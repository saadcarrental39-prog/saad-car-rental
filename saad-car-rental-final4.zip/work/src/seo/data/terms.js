// "People also search for": natural search phrases generated from the data, so a new place / vehicle / service added to the data files
// gets its related-search list automatically at the next build. The phrases are shown as visible text at the bottom of the page.
import { place } from "./places";
import { SERVICE_PAGES } from "./services";
import { VEHICLE_FIT } from "./vehicles";
import { kw } from "./keywords";

const uniq = (a) => [...new Set(a.map((x) => x.trim()).filter(Boolean))];
const VEH_NAME = { "land-cruiser-v8": "Land Cruiser V8", "land-cruiser-tz": "Land Cruiser TZ", prado: "Prado", revo: "Hilux Revo", "honda-civic": "Honda Civic", "toyota-grande": "Toyota Corolla Grande", "range-rover": "Range Rover", coaster: "Toyota Coaster" };

export function termsFor(page) {
  const k = page.kind;
  if (k === "keyword") { const e = kw(page.slug); return e ? e.terms || [] : []; }
  if (k === "vehicle") {
    const n = VEH_NAME[page.slug] || page.h1; const fit = VEHICLE_FIT[page.slug] || [];
    return uniq([`${n} for rent in Islamabad`, `${n} rental with driver`, `${n} on rent Islamabad`, `rent a ${n} Rawalpindi`, `${n} hire Pakistan`, `${n} rent per day`, fit.includes("wedding") && `${n} for wedding`, fit.includes("northern") && `${n} for northern areas tour`, `${n} gari kiraye par`]);
  }
  if (k === "destination" || k === "route") {
    const p = place(k === "route" ? page.slug.replace(/^islamabad-to-/, "") : page.slug); if (!p) return [];
    const n = p.short || p.name;
    return uniq([`Islamabad to ${n} car rental`, `Islamabad to ${n} with driver`, `rent a car Islamabad to ${n}`, `Islamabad to ${n} taxi`, `${n} tour from Islamabad by car`, `${n} trip with private driver`, `Islamabad to ${n} by road`, `car for ${n} trip`, `${n} ke liye gari kiraye par`]);
  }
  if (k === "location") {
    const p = place(page.slug); if (!p) return []; const n = p.short || p.name;
    return uniq([`rent a car ${n}`, `car rental ${n}`, `car with driver ${n}`, `${n} car hire`, `${n} airport car rental`, `Prado rent ${n}`, `${n} chauffeur service`, `gari kiraye par ${n}`]);
  }
  if (k === "service") {
    const s = SERVICE_PAGES.find((x) => x.slug === page.slug); if (!s) return [];
    return uniq([s.kw, `${s.kw} near me`, `${s.name} Islamabad`, `${s.name} Rawalpindi`, `${s.name} Pakistan`, `${s.name} with driver`, `book ${s.name.toLowerCase()} online`]);
  }
  if (k === "airport") return ["Islamabad airport pickup", "Islamabad airport drop", "Islamabad airport taxi", "airport transfer Islamabad", "car with driver Islamabad airport", "Islamabad airport car rental", "airport pick and drop Islamabad", "new Islamabad airport pickup service"];
  if (k === "province") return [`car rental ${page.h1.replace(/^Car Rental With Driver in /, "")}`, `${page.h1.replace(/^Car Rental With Driver in /, "")} tour car with driver`, `rent a car from Islamabad to ${page.h1.replace(/^Car Rental With Driver in /, "")}`];
  return [];
}
