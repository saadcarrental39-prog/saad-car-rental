// ============================================================================
//  LEGAL PAGES: Privacy Policy, Terms, Disclaimer, Cookie Policy, Booking / Cancellation / Refund.
//  Written from what this website REALLY does (forms, WhatsApp, anonymous visit counter, partially-typed forms saved for follow-up,
//  Google reviews, Google Maps, Google Fonts, Cloudflare hosting). Business facts are read from business.config.js.
//  No prices, no invented percentages, no invented legal registrations. Where a rule depends on the owner (advance payment,
//  cancellation charges), the text says "as agreed in your confirmed quote" instead of making up a number.
//
//  Section content `c` is an array: a string = paragraph, an array of strings = bullet list.
//  HOW TO EDIT: change the text here, rebuild. LEGAL_UPDATED is shown on every legal page.
//  NOTE: these are professional drafts, not legal advice. Have a lawyer in Pakistan read them once before you rely on them.
// ============================================================================
import { BUSINESS as B } from "../../business.config";

export const LEGAL_UPDATED = "10 October 2026";
const NAME = B.businessName;
const PHONE = B.phoneDisplay;
const ADDR = B.addressLines.join(" ").replace(/\s+/g, " ").replace(/,\s*,/g, ",").trim();
const MAIL = B.email ? ` or email ${B.email}` : "";
const LEGAL = B.legalBusinessName ? `${B.legalBusinessName} (trading as ${NAME})` : NAME;
const f = (q, a) => ({ q, a });
const contactSection = (extra = "") => ({ id: "contact", h: "Contact us", c: [
  `If you have a question about this page${extra}, contact ${NAME} at ${ADDR}. You can call or WhatsApp ${PHONE}${MAIL}. We reply as soon as we can during working hours.`] });

export const LEGAL_DOCS = [
  // ------------------------------------------------------------------------------------------------ PRIVACY
  { slug: "privacy-policy", path: "/privacy-policy", name: "Privacy Policy", title: "Privacy Policy", h1: "Privacy Policy",
    description: `How ${NAME} collects, uses, stores and protects your information when you use our website, call us, WhatsApp us or book a car with a driver.`,
    og: { a: "PRIVACY POLICY", b: "How we protect your information" },
    lead: `Your trust matters to us. This policy explains in plain language what information ${NAME} collects when you visit our website or book a car with a professional driver, why we collect it, who can see it and what choices you have.`,
    summary: [
      "We collect only what you type into our forms, what you send us on WhatsApp or by phone, and anonymous visit statistics.",
      "We never sell your personal information and we do not use it for third-party advertising.",
      "Details you type into a booking or contact form may be saved even if you do not press Send, so that we can follow up on your enquiry.",
      "Our visit counter does not store your name, phone number or IP address.",
      "You can ask us to correct or delete your details at any time.",
    ],
    sections: [
      { id: "who", h: "Who we are and what this policy covers", c: [
        `This website is operated by ${LEGAL}, a car rental with professional driver (chauffeur) service based at ${ADDR}. In this policy, "we", "us" and "our" mean ${NAME}. "You" means anyone who visits our website, contacts us or books a vehicle through us.`,
        "This policy covers our website, the booking and enquiry forms on it, our phone and WhatsApp communication with you, and the anonymous statistics we keep about how the website is used. It does not cover websites run by other companies that you may reach through links from our pages." ] },
      { id: "collect", h: "Information we collect", c: [
        "We collect information in three ways.",
        "1. Information you give us. When you use the Book Now form, the Contact form or send us a message, you may give us:",
        ["Your name, phone number, WhatsApp number and email address", "Your pickup point, destination, travel date and time, and number of passengers", "The vehicle you are interested in and any notes or special requests you type", "The content of messages you send us by WhatsApp, SMS, email or phone, and the details of calls we receive"],
        "2. Information collected automatically. Our website keeps an anonymous visit counter so that we can see which pages are useful. It records the page visited, the type of device (mobile, tablet or desktop), how you reached us (for example Google, WhatsApp or direct), the approximate country and city your connection appears to come from, and a random identification code created in your browser. This random code is not your name and cannot by itself identify you. Our counter does not store your IP address, name or phone number.",
        "3. Information from other services. Our pages can show review information that Google publishes about our business. We do not receive your personal details from Google when you read those reviews." ] },
      { id: "partial", h: "Partly completed forms", c: [
        "If you type contact details or trip details into one of our forms, what you have typed may be saved on our systems even if you leave the page without pressing Send. We do this so that a member of our team can contact you and help you complete your booking. Our forms tell you that this happens. If you do not want your details kept, do not type them, or contact us and ask us to delete them." ] },
      { id: "use", h: "How we use your information", c: [
        "We use your information only for purposes connected with running our service:",
        ["To reply to your enquiry, prepare a quote and confirm your vehicle, driver and timing", "To carry out your booking, including contacting you about pickup, delays or changes", "To prepare booking confirmations and receipts", "To keep a record of bookings and enquiries for our own business and accounting needs", "To understand how the website is used and to improve pages, speed and content", "To protect the website and our systems from spam, abuse and technical problems", "To meet legal obligations that apply to us"],
        "We do not use your details to make automated decisions about you, and we do not sell, rent or trade your personal information." ] },
      { id: "basis", h: "Why we are allowed to use your information", c: [
        "We handle personal information in line with the laws of Pakistan that apply to us and with widely accepted privacy principles: we collect only what we need, we use it for the purpose you gave it for, we keep it only as long as needed and we protect it. We use your information because you asked us for a quote or booking (to take steps you requested), because we have a genuine business interest in running and improving a safe, reliable service, because you have chosen to contact us, and where the law requires it." ] },
      { id: "whatsapp", h: "WhatsApp, calls and messages", c: [
        "Many customers contact us on WhatsApp or by phone. When you message us on WhatsApp, the message is also handled by WhatsApp, which is operated by Meta and has its own privacy policy. The booking form can prepare a message for you to send to our WhatsApp chat; nothing is sent from your phone until you press Send. We may also receive a copy of your booking details by WhatsApp so that our team can act on it quickly. We use your number only to deal with your enquiry or booking and to contact you about it." ] },
      { id: "services", h: "Service providers we rely on", c: [
        "To run the website we use trusted technology providers. They process information on our behalf and only for those purposes:",
        ["Cloudflare, which hosts and protects the website and stores the booking, enquiry and visit records described above", "Google Fonts, which supplies the typefaces used on our pages (your browser requests the font files from Google)", "Google Maps, which shows our office location on the Contact page", "Google Analytics and Cloudflare Web Analytics, which we may switch on to measure visits in aggregate", "WhatsApp (Meta), which carries messages you send us and booking notices to our team"],
        "These providers may handle information on servers in several countries. We choose providers that apply security measures appropriate to the information they handle." ] },
      { id: "sharing", h: "Who sees your information", c: [
        "Your details are seen by our own team and by the driver assigned to your trip, and only as much as is needed to carry out the booking. We do not sell your information. We may disclose information if the law requires it, if a competent authority makes a valid request, to protect the safety of passengers or drivers, or to protect our legal rights. If our business is ever sold or reorganised, customer records may be transferred to the new owner on the same terms as this policy." ] },
      { id: "transfers", h: "Information stored or processed abroad", c: [
        "Our providers operate worldwide, so information you submit may be stored or processed in countries other than Pakistan. By using the website and sending us your details you understand that this can happen. We use reputable providers and do not allow them to use your details for their own marketing." ] },
      { id: "retention", h: "How long we keep information", c: [
        "We keep enquiry and booking details for as long as we need them to deal with your request and for a reasonable period afterwards, normally up to about two years, so that we can answer follow-up questions, handle any dispute and keep proper business records. Visit statistics are kept in anonymous form. Where the law requires us to keep a record for longer, we keep it for that period. After that we delete or anonymise the information." ] },
      { id: "security", h: "How we protect information", c: [
        "We use technical and organisational safeguards: encrypted connections (HTTPS) on the website, access to booking records limited to authorised staff and protected by sign-in, spam protection on forms, and server-side storage of secret keys. No online service can be completely secure, so please do not send us card numbers, passwords or government identity numbers through the website forms." ] },
      { id: "rights", h: "Your choices and rights", c: [
        "You can ask us at any time to:",
        ["Tell you what personal information we hold about you", "Correct anything that is wrong or out of date", "Delete your details from our records", "Stop contacting you about a past enquiry"],
        `To make a request, call or WhatsApp ${PHONE}${MAIL} and tell us the name and phone number you used. We may ask for a little information to confirm that the request really comes from you. If you live in a region whose privacy law gives you specific rights, we will respect those rights to the extent they apply to us.` ] },
      { id: "children", h: "Children", c: [
        "Our website and service are meant for adults who book travel. We do not knowingly collect personal information from children. If you believe a child has sent us details, contact us and we will remove them." ] },
      { id: "links", h: "Links to other websites", c: [
        "Some pages link to other sites such as Google Maps or WhatsApp. We are not responsible for the content or privacy practices of those sites, so please read their policies before you share information with them." ] },
      { id: "changes", h: "Changes to this policy", c: [
        `We may update this policy when our service or the law changes. The date at the top of the page shows the latest version. If we make an important change we will make it clear on the website. Please also read our Cookie Policy, our Terms and Conditions and our Disclaimer.` ] },
      contactSection(" or about your information"),
    ],
    faqs: [
      f("Does Saad Car Rental sell my personal information?", "No. We never sell, rent or trade your personal information. It is used only to answer your enquiry, carry out your booking and run our service."),
      f("What information do I give when I book a car with a driver?", "You give your name, phone or WhatsApp number, pickup and destination, travel date and time, number of passengers and any notes you choose to type. Email is optional."),
      f("Is the information I type in a form saved if I do not press Send?", "It may be. Details typed into our forms can be saved so that our team can contact you about your enquiry. You can ask us to delete them at any time."),
      f("How can I ask you to delete my details?", `Call or WhatsApp ${PHONE}${MAIL}, tell us the name and phone number you used, and we will remove your details from our records.`),
    ] },

  // ------------------------------------------------------------------------------------------------ TERMS
  { slug: "terms-and-conditions", path: "/terms-and-conditions", name: "Terms and Conditions", title: "Terms and Conditions of Car Rental With Driver", h1: "Terms and Conditions",
    description: `The terms for using the ${NAME} website and booking a car with a driver: quotes, bookings, payment, passengers, safety and liability.`,
    og: { a: "TERMS & CONDITIONS", b: "Car rental with professional driver" },
    lead: `These terms explain how bookings with ${NAME} work, what we expect from passengers and what you can expect from us. Please read them before you book. By using our website or confirming a booking you agree to them.`,
    summary: [
      "Every vehicle is provided with a professional driver. Self-drive is not part of our standard service.",
      "A website form is a request, not a confirmed booking. A booking is confirmed when our team confirms your vehicle and driver.",
      "We quote each trip individually. What is included in your price is written in your confirmed quote.",
      "Drivers may change or stop a route when safety, weather or road conditions require it.",
    ],
    sections: [
      { id: "about", h: "About these terms", c: [
        `These terms apply between you and ${LEGAL} ("we", "us"), a car rental with professional driver service based at ${ADDR}. They cover your use of our website and every booking we confirm for you. If we agree something different with you in writing for a particular booking, that agreement applies to that booking.` ] },
      { id: "service", h: "Our service", c: [
        "We provide cars, SUVs, pickups and a Coaster together with an experienced professional driver for airport transfers, city travel, business and family journeys, weddings and events, intercity trips and journeys to the northern areas of Pakistan. Our vehicles are provided with a driver. If you are looking for a vehicle to drive yourself, please call us first to find out whether anything can be arranged.",
        "We are based in Islamabad. Most journeys start in Islamabad or Rawalpindi. Where we offer travel to or from another city, we do so as a chauffeur-driven trip from our Islamabad base, and we confirm any pickup elsewhere with you before you travel." ] },
      { id: "quotes", h: "Quotes and bookings", c: [
        "We do not publish fixed prices, because the right price depends on the vehicle, route, number of days, season and your requirements. To get a quote, call us, message us on WhatsApp or use the Book Now form with your pickup, destination, date, time and number of passengers.",
        "A quote is valid for the date and details you gave us and may change if those details change. Submitting a form or sending a message is a request only. A booking exists when our team confirms the vehicle, driver, date and price with you by phone, WhatsApp or another written message. Popular dates, such as weddings, long weekends and the summer season in the north, can fill quickly, so please book early." ] },
      { id: "price", h: "Price and payment", c: [
        "The price for your trip is the price in your confirmed quote. Your quote tells you what is included. Costs such as tolls, parking, driver overnight stay, waiting time beyond the agreed time, extra stops or extra distance may be additional unless your quote says they are included, so please ask us if you are unsure.",
        "How and when you pay, and whether an advance is needed to hold a vehicle, is agreed with you when the booking is confirmed. Please pay only through the payment details our team gives you directly and keep your payment record." ] },
      { id: "changes", h: "Changes and cancellations", c: [
        "Please tell us as early as possible if your plan changes. We will try to accommodate changes to dates, times and routes, subject to vehicle and driver availability and to a revised quote where needed. Cancellation and refund arrangements are set out on our Booking, Cancellation and Refund Policy page and in your confirmed quote." ] },
      { id: "passengers", h: "What we ask of passengers", c: [
        "To keep everyone safe and comfortable, we ask passengers to:",
        ["Give accurate information about the number of passengers, luggage and the places you want to visit", "Be ready at the agreed place and time, and tell us promptly if you will be late", "Use seat belts and follow the driver's reasonable safety instructions", "Not carry anything illegal, dangerous or unsafe in the vehicle", "Treat the vehicle with care; you may be asked to pay for damage or special cleaning caused by passengers", "Behave respectfully towards the driver and other passengers"],
        "The driver may refuse or end a journey if a passenger's behaviour or request makes it unsafe or unlawful to continue." ] },
      { id: "driver", h: "Drivers and vehicles", c: [
        "Your driver is responsible for operating the vehicle safely and lawfully and has the final say on driving decisions, including speed, stops, rest breaks and whether a road is safe to use. If the exact vehicle you chose is not available on the day, for example because of a breakdown, we may provide a vehicle of the same or higher class and will tell you as early as we can. Photographs on the website show the type of vehicle; colour and exact model year can differ." ] },
      { id: "north", h: "Mountain roads, weather and road closures", c: [
        "Routes in the north and in the hills depend on weather, landslides, snow, floods, security directions and official road closures, and some passes and valleys open only in certain months. If conditions make part of a trip unsafe or impossible, we will discuss alternatives with you, such as a different route, a changed schedule or a shorter trip. Delays and changes caused by weather, road conditions or official orders are outside our control." ] },
      { id: "luggage", h: "Luggage and belongings", c: [
        "Please tell us about your luggage when you book so that we can choose a suitable vehicle. Keep valuables, documents, money and medicines with you. We are not responsible for items left in a vehicle, although if a driver finds something we will try to return it to you." ] },
      { id: "liability", h: "Our responsibility to you", c: [
        "We will provide the service with reasonable skill and care. We are responsible for loss or damage you suffer that is a foreseeable result of our failing to do so. We are not responsible for indirect or consequential loss, for loss of business or opportunity, or for delay or failure that results from events outside our reasonable control, including severe weather, natural disasters, road closures, strikes, security situations, government orders and traffic. Nothing in these terms removes any right you have under the law that cannot be limited, and nothing limits responsibility for death or personal injury caused by negligence where the law does not allow it." ] },
      { id: "control", h: "Events outside our control", c: [
        "If an event outside our reasonable control prevents or delays a trip, neither of us is in breach of these terms for the period it lasts. We will tell you as soon as we can and will work with you to rearrange the trip or, where the trip cannot take place, to deal fairly with any amount you have already paid for service that was not delivered." ] },
      { id: "website", h: "Use of this website", c: [
        "You may use the website for lawful personal and business enquiries. Please do not copy or republish our text, photographs or logo without permission, do not use automated tools to collect large parts of the site, do not try to interfere with its security or operation and do not submit false or misleading enquiries. The business name, logo, text and images on the website belong to us or are used with permission. Vehicle brands and model names belong to their owners." ] },
      { id: "reviews", h: "Reviews", c: [
        "Reviews on the website are real reviews that customers have published on Google. We do not write reviews for customers or pay for them. We may stop showing a review that breaks Google's rules or the law." ] },
      { id: "privacy", h: "Your information", c: [
        "How we handle personal information is explained in our Privacy Policy and Cookie Policy, which form part of these terms." ] },
      { id: "law", h: "Governing law and disputes", c: [
        "These terms are governed by the laws of Pakistan. If something goes wrong, please contact us first so that we can try to put it right quickly. If a dispute cannot be settled between us, the competent courts at Islamabad will have jurisdiction, unless the law gives you the right to bring a claim somewhere else." ] },
      { id: "changes-terms", h: "Changes to these terms", c: [
        "We may update these terms from time to time. The version that applies to your booking is the version published on the date you confirmed it. The date at the top of the page shows the latest update." ] },
      contactSection(" or your booking"),
    ],
    faqs: [
      f("Is a website booking form a confirmed booking?", "No. A form is a request. A booking is confirmed when our team confirms your vehicle, driver, date and price with you by phone or WhatsApp."),
      f("Are tolls, parking and overnight stays included in the price?", "That depends on your trip. Your confirmed quote states what is included. Items such as tolls, parking, driver overnight stay or extra waiting time may be additional unless the quote says they are included."),
      f("Can the driver change the route?", "Yes, when safety, weather, road conditions or official closures require it. The driver decides on safety matters, and we discuss alternatives with you."),
      f("Can I drive the car myself?", "Our vehicles are provided with a professional driver. If you want to drive yourself, please call us to ask whether anything can be arranged."),
    ] },

  // ------------------------------------------------------------------------------------------------ DISCLAIMER
  { slug: "disclaimer", path: "/disclaimer", name: "Disclaimer", title: "Website and Travel Disclaimer", h1: "Disclaimer",
    description: `Important limits on the ${NAME} website content: general information, road conditions, vehicle photos, reviews and third-party links.`,
    og: { a: "DISCLAIMER", b: "Please read before you travel" },
    lead: `The information on this website is written to help you plan a journey with ${NAME}. Travel in Pakistan, especially in the mountains, depends on conditions that change. This disclaimer explains the limits of what our pages can tell you.`,
    summary: [
      "Pages on this website are general information, not professional, legal, medical or official travel advice.",
      "Road, weather, season and destination notes are general and can change. Always confirm current conditions with us before you travel.",
      "Vehicle photographs show the type of vehicle. Colour, model year and availability are confirmed when you book.",
      "We are an independent car rental with driver service and are not affiliated with any vehicle manufacturer.",
    ],
    sections: [
      { id: "general", h: "General information only", c: [
        `Everything on this website is provided for general information about the services of ${NAME}. It is not intended as professional, legal, financial, medical or official travel advice, and you should not treat it as such. We work to keep the information useful, but we cannot promise that every statement is complete or free of error at the moment you read it.` ] },
      { id: "conditions", h: "Roads, weather and seasons", c: [
        "Our route and destination pages describe journeys in general terms: the type of road, the usual season and the kind of vehicle that suits it. Mountain roads, passes and valleys can close or become difficult because of snow, rain, landslides, flooding, construction, security directions or official orders, sometimes at very short notice. A place that is open in one week may be closed the next. Before you travel, please ask us for current advice for your dates and also check official sources such as the relevant district or highway authorities and weather forecasts." ] },
      { id: "times", h: "Journey times and distances", c: [
        "We deliberately do not publish fixed journey times or distances on our pages, because real travel time depends on traffic, road conditions, weather, rest stops and the plan you agree with your driver. Any time or distance mentioned to you in conversation is an estimate, not a promise." ] },
      { id: "fleet", h: "Vehicles, photographs and availability", c: [
        "Photographs show the type and appearance of our vehicles. The colour, trim and model year of the vehicle assigned to you can differ from the picture, and a vehicle of the same or higher class may be provided if the one you chose is not available. Some vehicles, such as the Range Rover and the Coaster, are available on request and are confirmed for your date when you enquire. A vehicle appearing on the website does not mean it is free on every date." ] },
      { id: "prices", h: "Prices and quotes", c: [
        "No prices are published on this website. Every trip is quoted individually by phone or WhatsApp, and the price you are given in a confirmed quote is the price that applies to your booking." ] },
      { id: "risk", h: "Travel involves risk", c: [
        "Road travel, particularly on mountain routes, at altitude and in changing weather, carries some risk. Our drivers are experienced and drive with care, but we cannot remove every risk. Passengers travel in line with our Terms and Conditions. Please consider travel insurance and tell us in advance about any health condition, mobility need or medical requirement that could affect your journey, and carry the medicines you need." ] },
      { id: "reviews", h: "Ratings and reviews", c: [
        "Review information and the Google rating shown on our pages come from reviews published by customers on Google and reflect the position at the time they were collected. They can change. Reviews express the opinions of the people who wrote them." ] },
      { id: "links", h: "Third-party content and links", c: [
        "Our pages may include maps, fonts, review information and links supplied by other companies. We do not control those services and are not responsible for their content, availability or privacy practices." ] },
      { id: "brands", h: "Brands and independence", c: [
        "Toyota, Land Cruiser, Prado, Hilux, Revo, Coaster, Honda, Civic, Corolla, Range Rover and other vehicle names are trademarks of their respective owners and are used only to describe the vehicles we provide. We are an independent car rental with driver service and are not affiliated with, sponsored by or endorsed by any vehicle manufacturer." ] },
      { id: "site", h: "Website availability and accuracy", c: [
        "We try to keep the website available and accurate, but we do not promise that it will always work without interruption or errors. We may change, suspend or remove content at any time without notice." ] },
      { id: "limit", h: "Limit of our responsibility", c: [
        "To the fullest extent the law allows, we are not responsible for loss that results from your reliance on information on this website alone, instead of confirming details with us. This disclaimer does not limit any responsibility that cannot be limited by law, and it does not replace the terms of a confirmed booking, which are set out in our Terms and Conditions." ] },
      { id: "law", h: "Governing law", c: [
        "This disclaimer is governed by the laws of Pakistan." ] },
      contactSection(" or to confirm current conditions for your trip"),
    ],
    faqs: [
      f("Is the information on the website official travel advice?", "No. It is general information to help you plan. Please confirm current road, weather and seasonal conditions with us and with official sources before you travel."),
      f("Will the car I book look exactly like the photograph?", "The photograph shows the type of vehicle. Colour and model year can differ, and a vehicle of the same or higher class may be provided if yours is unavailable. We confirm the details when you book."),
      f("Are you connected to Toyota, Honda or Land Rover?", "No. We are an independent car rental with driver service. Vehicle brand names belong to their owners and are used only to describe our vehicles."),
      f("Why are journey times not shown on your pages?", "Real travel time depends on traffic, weather, road conditions and rest stops, so we give you an estimate for your specific date when you contact us."),
    ] },

  // ------------------------------------------------------------------------------------------------ COOKIES
  { slug: "cookie-policy", path: "/cookie-policy", name: "Cookie Policy", title: "Cookie and Local Storage Policy", h1: "Cookie and Local Storage Policy",
    description: `What cookies and browser storage the ${NAME} website uses, why, which third parties may set cookies, and how you can control or remove them.`,
    og: { a: "COOKIE POLICY", b: "Cookies and browser storage" },
    lead: `This page explains the small pieces of information our website stores in your browser, what each one is for and how you can control them. We keep this to the minimum needed to make the site work and to count visits anonymously.`,
    summary: [
      "We do not use advertising or cross-site tracking cookies.",
      "We store a few small items in your browser to keep the site working and to count visits without identifying you.",
      "Analytics from Google or Cloudflare are used only if switched on for the website.",
      "You can delete or block cookies and site storage in your browser settings at any time.",
    ],
    sections: [
      { id: "what", h: "What are cookies and browser storage?", c: [
        "Cookies are small text files that a website asks your browser to keep. Browsers also offer similar tools, called local storage and session storage, that let a website remember small items on your device. Local storage stays until you delete it. Session storage disappears when you close the tab. In this policy we call all of them simply \"storage\"." ] },
      { id: "use", h: "What our website stores", c: [
        "Our website itself uses the following kinds of storage:",
        ["A random visitor code (local storage) and a random visit code (session storage). They let our own anonymous counter tell a new visitor from a returning one. They contain no name, phone number or IP address.", "The source of your visit (session storage): the website that sent you to us and the first page you opened, so we can see which pages bring enquiries.", "Display preferences (local storage), for example whether the vehicle sound effect is switched on or off, and a saved copy of vehicle display details so the page loads faster.", "A small review summary and recovery flag (session storage) that make the page load faster and help it reload itself if something goes wrong."],
        "These items make the website work smoothly or help us understand it in aggregate. We do not use them to build advertising profiles." ] },
      { id: "analytics", h: "Analytics", c: [
        "To learn which pages help visitors, our website counts page views and key actions such as phone, WhatsApp and booking button clicks. The website can also send these anonymous events to Google Analytics (which may set cookies such as _ga) and to Cloudflare Web Analytics (which is designed to work without cookies), but only when the website owner has switched them on. We do not send names, phone numbers or other personal details to analytics services." ] },
      { id: "third", h: "Third-party services on our pages", c: [
        "Some features load content from other companies, who may set their own cookies or receive technical information such as your IP address and browser type when your browser contacts them:",
        ["Google Maps on the Contact page", "Google Fonts for typefaces", "Google, for review information about our business", "WhatsApp, when you press a WhatsApp button and open a chat"],
        "Please read the privacy and cookie policies of those companies to see how they handle information." ] },
      { id: "control", h: "How to control or delete storage", c: [
        "You can control storage in your browser settings. Most browsers let you see what is stored, delete it, block it for all sites or for particular sites, and clear it every time you close the browser. If you block or delete our storage, the website still works, but we may count you as a new visitor and a few display preferences will reset. To stop Google Analytics, you can use the opt-out tools Google provides for browsers." ] },
      { id: "consent", h: "Your consent and changes", c: [
        "By continuing to use our website you accept the storage described here. If we add a new kind of storage, we will update this page and the date at the top. For how we handle personal information more broadly, read our Privacy Policy." ] },
      contactSection(" or about the storage we use"),
    ],
    faqs: [
      f("Does the Saad Car Rental website use advertising cookies?", "No. We do not use advertising or cross-site tracking cookies. We store a few small items to make the site work and to count visits anonymously."),
      f("Is the visitor code my name or phone number?", "No. It is a random code made by your browser. It does not contain your name, phone number or IP address."),
      f("What happens if I block cookies and storage?", "The website still works. We may count you as a new visitor on each visit and a few display preferences will reset."),
    ] },

  // ------------------------------------------------------------------------------------------------ CANCELLATION / REFUND
  { slug: "cancellation-and-refund-policy", path: "/cancellation-and-refund-policy", name: "Booking, Cancellation and Refund Policy", title: "Booking, Cancellation and Refund Policy", h1: "Booking, Cancellation and Refund Policy",
    description: `How booking confirmation, changes, cancellations, weather and road closures, and refunds work for a car with driver booked with ${NAME}.`,
    og: { a: "BOOKING & REFUNDS", b: "Changes, cancellations and refunds" },
    lead: `Plans change, and mountain weather changes faster than most. This page explains, step by step, how a booking is confirmed, how to change or cancel it, what happens if we or the weather change the plan, and how refunds are handled.`,
    summary: [
      "A booking is confirmed when our team confirms your vehicle, driver, date and price.",
      "Tell us as early as possible if you need to change or cancel; early notice gives us the best chance to help.",
      "Cancellation terms for your trip are stated in your confirmed quote.",
      "If we cannot provide the service, you will not be charged for it, and amounts paid for service not delivered are refunded.",
    ],
    sections: [
      { id: "confirm", h: "How a booking is confirmed", c: [
        "A booking is not final when you fill in a form or send a message. It is final when our team confirms to you, by phone, WhatsApp or another written message, the vehicle, driver, date, pickup, route and price. Please check those details carefully when we confirm them and tell us straight away if anything is wrong. Any receipt or summary produced by the website lists the details you entered and does not by itself confirm a booking." ] },
      { id: "payment", h: "Payment", c: [
        "Whether an advance payment is needed to hold a vehicle, how much, and how you pay are agreed with you at confirmation and are never a surprise on the day. Please pay only through the payment details our team gives you directly, and keep a record of every payment. We do not ask for payment through unsolicited links or accounts that our team has not shared with you." ] },
      { id: "change", h: "If you need to change your booking", c: [
        "Contact us as soon as you know. We will do our best to move your date or time, change your route or switch your vehicle, subject to availability. A change may mean a different quote, for example if the distance, number of days or vehicle changes, and we will tell you before you agree." ] },
      { id: "cancel", h: "If you need to cancel", c: [
        "Please tell us by phone or WhatsApp as early as you can. The cancellation terms that apply to your trip, including whether any charge applies and how it is calculated, are stated in your confirmed quote. In general, the earlier you tell us, the more likely it is that we can release the vehicle and driver to another customer and the less you are likely to be asked to pay. If you do not arrive and do not tell us, the booking may be treated as cancelled on the day." ] },
      { id: "ours", h: "If we have to change or cancel", c: [
        "If a vehicle or driver becomes unavailable we will tell you as early as possible and offer a vehicle of the same or higher class where we can. If we cannot provide the service at all, we will not charge you for it and we will refund any amount you have paid for service that was not delivered." ] },
      { id: "weather", h: "Weather, road closures and safety", c: [
        "Mountain and hill journeys can be affected by snow, rain, landslides, floods, official closures and security directions. Where conditions make the trip unsafe or impossible, we will discuss alternatives with you, such as a different route, a delayed start, a shortened trip or a new date. If part of a booked service cannot be delivered for these reasons, we will agree with you in fairness how to treat the amount for the part not delivered. The driver's decision on safety is final." ] },
      { id: "mid", h: "If you end a trip early", c: [
        "If you decide to end a multi-day trip early, tell the driver and contact our office. Costs already incurred for the vehicle and driver, such as days already travelled and the driver's return, will be taken into account as explained in your confirmed quote." ] },
      { id: "refund", h: "How refunds are handled", c: [
        "When a refund is due, we return it to you using the same method you used to pay, or another method we agree with you, as soon as practical after we confirm it. The time it takes to reach you also depends on your bank or payment service. We will tell you the amount and how it was calculated." ] },
      { id: "problem", h: "If something goes wrong", c: [
        "If you are not happy with part of your trip, please tell your driver or our office during the journey so that we can put it right at once. After the trip, contact us with the details of your booking and we will look into it fairly and reply as soon as we can." ] },
      { id: "related", h: "Related policies", c: [
        "This page works together with our Terms and Conditions, our Disclaimer and our Privacy Policy." ] },
      contactSection(" or to change or cancel a booking"),
    ],
    faqs: [
      f("When is my booking confirmed?", "When our team confirms your vehicle, driver, date, pickup and price by phone, WhatsApp or another written message. A website form is only a request."),
      f("How do I cancel a booking?", `Call or WhatsApp ${PHONE} as early as you can. The cancellation terms for your trip are stated in your confirmed quote.`),
      f("What if bad weather or a road closure stops my northern trip?", "We discuss alternatives with you, such as another route, a delayed start, a shorter trip or a new date, and agree fairly how to treat the part of the service that could not be delivered."),
      f("How long does a refund take?", "We return a refund by the same payment method, or another agreed method, as soon as practical after we confirm it. Bank processing time also affects when it reaches you."),
    ] },
];

export const legalBySlug = (slug) => LEGAL_DOCS.find((d) => d.slug === slug);
export const legalText = (d) => [d.lead, ...d.summary, ...d.sections.flatMap((s) => [s.h, ...s.c.flat()]), ...d.faqs.map((x) => `${x.q} ${x.a}`)].join(" ");
