// YOUR OWN KEYWORD PAGES. Add a new page by running:   npm run keywords:new -- "wedding car rental rawalpindi"
// The script appends a DRAFT entry below (a draft makes no page, so an unfinished entry can never break the build or reach Google).
// Fill in the text (look at city.js for a finished example), change  status: "draft"  to  status: "live",  then  npm run build.
// The page, its title, description, canonical, schema, FAQ markup, sitemap entry, share image, footer / topics / site-map links
// and the "people also search" block are then created automatically.
export const EXTRA = [
  // (new entries are added here by the script)
];
