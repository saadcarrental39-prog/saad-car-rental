// ============================================================================
//  KEYWORD PAGES: every search phrase people use to find a car with a driver in Pakistan gets a real, useful page.
//  Pages live at /<slug>. They are NOT in the main menu (customers who browse never need them), but they ARE in the sitemap, in
//  /car-rental-topics, in /site-map, in the footer "popular searches" and linked from related pages, so Google finds, crawls and ranks them.
//  Everything is visible text. Nothing is hidden from visitors: hidden keywords are against Google's spam policy and get sites removed from search.
//
//  Fields of one entry:
//   slug, group ("city" | "event" | "audience" | "guide" | "lang"), title (max 47 chars), h1, description (70-160 chars), eyebrow, lead,
//   answer: [question, short answer]            <- the "Short answer" box that Google / AI assistants quote
//   sections: [{ h, c: [paragraph | [bullet list]] }]   (3 sections; first before the vehicles, second before the places, third after)
//   faqs: [{ q, a }]   terms: ["search phrase", ...]  (shown as "People also search for")
//   vehicles / places / services / related: slugs (related = other keyword pages)
//   og: { a, b, vehicle }  service: schema serviceType   article: true (adds Article schema)   lang: "ur" | "rm"   status: "draft" hides it
// ============================================================================
import { CITY } from "./city";
import { PEOPLE } from "./people";
import { GUIDES } from "./guides";
import { LANG } from "./lang";
import { EXTRA } from "./extra";

export const KW_GROUPS = {
  city: { label: "Car rental in Islamabad and Rawalpindi", blurb: "The searches people type when they need a car with a driver in the twin cities: by the day, by the month, luxury, SUV, sedan, near me." },
  event: { label: "Weddings, Eid and holidays", blurb: "Bridal and barat cars, and holiday trips from Islamabad." },
  audience: { label: "For visitors, companies and families", blurb: "Tourists, overseas Pakistanis, business visitors, embassies, NGOs and family trips to the north." },
  guide: { label: "Guides and answers", blurb: "Clear answers to common questions about hiring a car with a driver and travelling in northern Pakistan." },
  lang: { label: "Urdu and Roman Urdu", blurb: "Gari kiraye par: the same service explained in Urdu and Roman Urdu." },
};

export const KW_PAGES = [...CITY, ...PEOPLE, ...GUIDES, ...LANG, ...EXTRA].filter((k) => k.status !== "draft").map((k) => ({ ...k, path: `/${k.slug}` }));
export const kw = (slug) => KW_PAGES.find((k) => k.slug === slug);
export const kwByGroup = (g) => KW_PAGES.filter((k) => k.group === g);
// The twelve most useful pages for the footer ("Popular searches"): in the order listed here, only if the page exists.
export const POPULAR = ["rent-a-car-islamabad", "car-rental-islamabad-per-day", "luxury-car-rental-islamabad", "suv-rental-islamabad-with-driver", "bridal-and-barat-car-rental-islamabad", "car-rental-rates-islamabad", "monthly-car-rental-with-driver-islamabad", "visit-pakistan-car-with-driver", "overseas-pakistanis-car-rental-islamabad", "northern-pakistan-road-trip-with-driver", "gari-kiraye-par-islamabad", "ur/car-rental-islamabad"].filter((s) => kw(s));
