// Legal pages: premium black-and-white document layout (hero, sticky contents list, numbered sections, key points card).
import { Link } from "react-router-dom";
import { pageByPath } from "./registry";
import { LEGAL_DOCS, legalBySlug, LEGAL_UPDATED } from "./data/legal";
import { Crumbs, Cta, Faq, Sec, LinkCards, Blocks } from "./blocks";

const pad = (i) => String(i + 1).padStart(2, "0");
export function LegalPage({ slug }) {
  const d = legalBySlug(slug); const pg = pageByPath(d.path);
  const others = LEGAL_DOCS.filter((x) => x.slug !== slug);
  return (<>
    <section className="lg-hero"><div className="sx-in">
      <Crumbs items={pg.breadcrumbs} />
      <p className="eyebrow">Legal</p>
      <h1>{d.h1}</h1>
      <p className="sx-lead">{d.lead}</p>
      <ul className="lg-meta"><li><span>Last updated</span><b>{LEGAL_UPDATED}</b></li><li><span>Applies to</span><b>Website and bookings</b></li><li><span>Governing law</span><b>Pakistan</b></li></ul>
    </div></section>
    <div className="lg-wrap sx-in">
      <aside className="lg-toc" aria-label="Contents"><p>Contents</p><ol>{d.sections.map((s, i) => <li key={s.id}><a href={`#${s.id}`}><i>{pad(i)}</i>{s.h}</a></li>)}</ol></aside>
      <article className="lg-doc">
        <div className="lg-key"><h2>Key points</h2><ul>{d.summary.map((x) => <li key={x}>{x}</li>)}</ul></div>
        {d.sections.map((s, i) => <section key={s.id} id={s.id} className="lg-sec"><span className="lg-n" aria-hidden="true">{pad(i)}</span><h2>{s.h}</h2><div className="lg-body"><Blocks c={s.c} /></div></section>)}
        <p className="lg-end">End of {d.name}. Last updated {LEGAL_UPDATED}.</p>
      </article>
    </div>
    <Faq items={d.faqs} title="Quick answers" />
    <Sec id="other" title="Other policies" tone="grey"><LinkCards items={others.map((x) => ({ to: x.path, title: x.name, text: x.description.split(". ")[0] }))} /></Sec>
    <Cta ctx={d.name} title="Questions about this page?" text="Call or WhatsApp us and our team will explain anything in plain language." />
  </>);
}
