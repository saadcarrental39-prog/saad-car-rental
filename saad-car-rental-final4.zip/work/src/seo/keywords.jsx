// Keyword landing pages (/<slug>), the topics hub (/car-rental-topics) and the HTML site map (/site-map).
// Pure render code, no browser APIs (rendered to HTML at build time by scripts/prerender.mjs).
import { Link } from "react-router-dom";
import { pageByPath, PAGES } from "./registry";
import { KW_PAGES, KW_GROUPS, kw, kwByGroup } from "./data/keywords";
import { SERVICE_PAGES } from "./data/services";
import { place, placePath } from "./data/places";
import { category, tripPath, tripLabel } from "./links";
import { termsFor } from "./data/terms";
import { LEGAL_DOCS } from "./data/legal";
import { Hero, Cta, Answer, Sec, Faq, LinkCards, VehicleStrip, Steps, BOOKING_STEPS, RelatedSearches, Blocks } from "./blocks";

const UI = {
  en: { short: "Short answer", veh: "Vehicles to choose from", places: "Trips and places", svc: "Related services", how: "How to book", faq: "Frequently asked questions", terms: "People also search for", rel: "Related pages" },
  ur: { short: "مختصر جواب", veh: "اپنی پسند کی گاڑی", places: "سفر اور مقامات", svc: "متعلقہ سروسز", how: "بکنگ کیسے کریں", faq: "اکثر پوچھے گئے سوالات", terms: "لوگ یہ بھی تلاش کرتے ہیں", rel: "متعلقہ صفحات",
    cta: { title: "آج کی دستیابی اور کوٹیشن حاصل کریں", text: "اپنی تاریخ، پک اپ اور منزل بتائیں۔ ہم کوٹیشن کے ساتھ جواب دیتے ہیں۔", labels: { call: "ابھی کال کریں", wa: "واٹس ایپ کریں", quote: "کوٹیشن لیں" } } },
  rm: { short: "Mukhtasar jawab", veh: "Apni pasand ki gari", places: "Safar aur maqamat", svc: "Mutaliqa services", how: "Booking kaise karein", faq: "Aksar pooche jane wale sawalat", terms: "Log ye bhi search karte hain", rel: "Mutaliqa pages",
    cta: { title: "Aaj ki availability aur quote lein", text: "Apni date, pickup aur manzil bataein. Hum quote ke sath jawab dete hain.", labels: { call: "Abhi call karein", wa: "WhatsApp karein", quote: "Quote lein" } } },
};
const placeCard = (p) => ({ to: p.basis === "base" || p.slug === "rawalpindi" ? placePath(p) : tripPath(p), title: p.basis === "base" || p.slug === "rawalpindi" ? p.name : tripLabel(p), text: p.highlights[0] });
const svcCard = (s) => ({ to: `/services/${s.slug}`, title: s.name, text: s.intro.split(". ")[0] + "." });

export function KeywordPage({ slug }) {
  const k = kw(slug); const pg = pageByPath(k.path); const ui = UI[k.lang || "en"]; let n = 0;
  const tone = () => (n++ % 2 ? undefined : "grey");
  const veh = (k.vehicles || []).map(category).filter(Boolean);
  const places = (k.places || []).map(place).filter((p) => p && p.status === "live");
  const svc = (k.services || []).map((s) => SERVICE_PAGES.find((x) => x.slug === s)).filter(Boolean);
  const rel = (k.related || []).map(kw).filter(Boolean);
  const [s0, s1, s2] = k.sections;
  const body = (<>
    <Hero eyebrow={k.eyebrow} h1={k.h1} lead={k.lead} crumbs={pg.breadcrumbs} />
    <Sec id="answer" title={k.answer[0]} tone={tone()}><Answer q={ui.short}>{k.answer[1]}</Answer></Sec>
    <Sec id="s0" title={s0.h} tone={tone()}><Blocks c={s0.c} /></Sec>
    {veh.length > 0 && <Sec id="vehicles" title={ui.veh} tone={tone()}><VehicleStrip cats={veh} /></Sec>}
    {s1 && <Sec id="s1" title={s1.h} tone={tone()}><Blocks c={s1.c} /></Sec>}
    {places.length > 0 && <Sec id="places" title={ui.places} tone={tone()}><LinkCards items={places.map(placeCard)} /></Sec>}
    {s2 && <Sec id="s2" title={s2.h} tone={tone()}><Blocks c={s2.c} /></Sec>}
    {svc.length > 0 && <Sec id="services" title={ui.svc} tone={tone()}><LinkCards items={svc.map(svcCard)} /></Sec>}
    <Sec id="how" title={ui.how} tone={tone()}><Steps items={k.steps || BOOKING_STEPS} /></Sec>
    <Faq items={k.faqs} title={ui.faq} />
    <RelatedSearches terms={termsFor(pg)} title={ui.terms} />
    {rel.length > 0 && <Sec id="related" title={ui.rel}><LinkCards items={rel.map((r) => ({ to: r.path, title: r.title }))} /></Sec>}
    <Cta ctx={k.title} {...(ui.cta || {})} />
  </>);
  return k.lang === "ur" ? <div lang="ur" dir="rtl" className="sx-rtl">{body}</div> : <div lang={k.lang === "rm" ? "ur-Latn" : undefined}>{body}</div>;
}

export function TopicsHub() {
  const p = pageByPath("/car-rental-topics"); let n = 0;
  return (<>
    <Hero eyebrow="Topics" h1={p.h1} lead="Every question people ask before hiring a car with a driver in Islamabad and across Pakistan, answered in one place: pricing, vehicles, weddings, visitors, overseas Pakistanis, northern trips and guides." crumbs={p.breadcrumbs} />
    {Object.entries(KW_GROUPS).map(([g, meta]) => { const list = kwByGroup(g); return list.length ? <Sec key={g} id={`g-${g}`} title={meta.label} tone={n++ % 2 ? undefined : "grey"}><p>{meta.blurb}</p><LinkCards items={list.map((x) => ({ to: x.path, title: x.title, text: x.lead.split(". ")[0] + "." }))} /></Sec> : null; })}
    <Cta ctx="Topics" />
  </>);
}

const group = (title, items, i) => items.length ? <Sec key={title} id={`m${i}`} title={title} tone={i % 2 ? undefined : "grey"}><ul className="sx-sitemap">{items.map((x) => <li key={x.path}><Link to={x.path}>{x.name}</Link></li>)}</ul></Sec> : null;
export function SitemapPage() {
  const p = pageByPath("/site-map"); const idx = PAGES.filter((x) => x.indexable);
  const by = (kinds) => idx.filter((x) => kinds.includes(x.kind)).map((x) => ({ path: x.path, name: x.breadcrumbs[x.breadcrumbs.length - 1].name === "Home" ? "Home" : x.h1 }));
  const sets = [
    ["Main pages", [{ path: "/", name: "Home" }, ...["/cars", "/services", "/about", "/contact", "/faq", "/car-rental-pakistan", "/northern-areas", "/locations", "/destinations", "/routes", "/airport-transfer/islamabad", "/car-rental-topics"].map((u) => { const x = pageByPath(u); return x && { path: u, name: x.h1 }; }).filter(Boolean)]],
    ["Our fleet", by(["vehicle"])], ["Services", by(["service"])], ["Cities and regions", by(["location", "province"])], ["Tourist destinations", by(["destination"])], ["Routes from Islamabad", by(["route"])],
    ...Object.entries(KW_GROUPS).map(([g, m]) => [m.label, kwByGroup(g).map((x) => ({ path: x.path, name: x.h1 }))]),
    ["Legal and policies", LEGAL_DOCS.map((d) => ({ path: d.path, name: d.h1 }))],
  ];
  return (<>
    <Hero eyebrow="Site map" h1={p.h1} lead="Every public page on this website, grouped by topic. Use it to find a vehicle, a service, a route or a policy quickly. Search engines can also read it to discover every page." crumbs={p.breadcrumbs} />
    {sets.map(([t, items], i) => group(t, items, i))}
    <Cta ctx="Site map" />
  </>);
}
export const PopularSearches = ({ slugs }) => slugs.map(kw).filter(Boolean).map((k) => <Link key={k.path} to={k.path}>{k.title}</Link>);
