# Keyword pages, legal pages and AI / Google setup

## What was added
- **5 legal pages** (black and white premium layout): /privacy-policy, /terms-and-conditions, /disclaimer, /cookie-policy, /cancellation-and-refund-policy. Text: `src/seo/data/legal.js`. They describe what the site really does (forms saved even if Send is not pressed, anonymous visit counter, Google Maps / Fonts, WhatsApp). **Have a lawyer in Pakistan read them once.** Check: cancellation terms, "courts at Islamabad", the "about two years" retention.
- **28 keyword landing pages** (rent a car Islamabad, per day, monthly, rates, self-drive, near me, luxury, SUV, 4x4, sedan, pick and drop, bridal/barat, embassies/NGOs, business visitors, tourists, overseas Pakistanis, Eid trips, family trips, 8 guides, Urdu and Roman Urdu). Text: `src/seo/data/keywords/*.js`.
- `/car-rental-topics` (all keyword pages), `/site-map` (every page), footer "popular searches" + legal links, "Popular searches" block on Home.
- **Related searches** (visible list of phrases) at the bottom of every vehicle, service, city, destination and route page, **generated automatically** from the data (`src/seo/data/terms.js`): add a place or vehicle and its phrases appear.
- **AI / GEO / AEO**: `llms.txt` + `llms-full.txt` (generated every build), robots.txt naming Googlebot, Bingbot, GPTBot, OAI-SearchBot, ClaudeBot, PerplexityBot, Google-Extended, Applebot and others, short "Short answer" boxes, FAQPage + Article + speakable + OfferCatalog schema, entries in `/.well-known/ai-catalog.json`.
- Sitemaps: `sitemap-keywords.xml`, `sitemap-legal.xml`. 35 new share images.

## Why nothing is hidden
Text that visitors cannot see but Google can (hidden keywords) is a spam violation: Google removes such sites from search. These pages are normal, visible, useful pages. They are simply not in the top menu, so customers who browse never need them, while Google finds them through the sitemap and links.

## Add a new keyword page (automatic from then on)
1. `npm run keywords:new -- "wedding car rental rawalpindi"` (adds a DRAFT entry to `keywords/extra.js`)
2. Fill in the text, set `status: "live"`.
3. `npm run build`. Page, title, schema, FAQ markup, sitemap, share image (`npm run seo:og`), topics / site-map links are created for you. The build refuses pages that are thin or copy each other.

## Find new keywords from real Google data
Search Console > Performance > Export > Queries.csv, then `npm run seo:suggest -- Queries.csv` lists real searches that have no page yet.

## After every deploy
`npm run indexnow` (Bing, Yandex etc. learn about all pages at once). For Google: submit `https://www.saadcarremtal.com/sitemap.xml` once in Search Console. No one can promise a ranking or a date; new pages usually take days to weeks.

## Still needed from you
Email address, legal business name, hours, map coordinates (BUSINESS-INFO-REQUIRED.md). They appear in the legal pages and schema automatically once added.
