import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { I18nProvider } from "./i18n";
import "./styles/i18n.css";
import App from "./App";
import { initFleet } from "./fleetSync";
import "./styles/automotive-carousel.css";
import "./styles/site.css";
import "./styles/seo.css";
import { initAnalytics } from "./analytics";
function Root() { // remounts once if the owner changed prices since this visitor's last visit
  const [k, setK] = useState(0);
  useEffect(() => { const f = () => setK((x) => x + 1); addEventListener("fleet-updated", f); return () => removeEventListener("fleet-updated", f); }, []);
  return <I18nProvider><BrowserRouter><App key={k} /></BrowserRouter></I18nProvider>;
}
initAnalytics();
initFleet().finally(() => createRoot(document.getElementById("root")).render(<Root />));

// Auto-refresh when a new version is deployed, so nobody keeps running old files.
if (import.meta.env.PROD) {
  const check = async () => {
    try {
      const r = await fetch(`/version.json?t=${Date.now()}`, { cache: "no-store" }); const { id } = await r.json();
      if (id && id !== __BUILD_ID__ && sessionStorage.getItem("v") !== id) {
        sessionStorage.setItem("v", id);
        try { for (const k of await caches.keys()) if (!k.startsWith("saad-admin")) await caches.delete(k); } catch { /* no Cache API */ }
        const u = new URL(location.href); u.searchParams.set("_r", id); location.replace(u.toString()); // fresh URL = fresh HTML (the ?_r marker is removed again by index.html)
      }
    } catch { /* offline: ignore */ }
  };
  check(); document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && check());
}
